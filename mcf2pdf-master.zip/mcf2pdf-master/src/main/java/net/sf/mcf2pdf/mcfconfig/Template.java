package net.sf.mcf2pdf.mcfconfig;

public class Template {
	private String name;
	private String filename;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
}
