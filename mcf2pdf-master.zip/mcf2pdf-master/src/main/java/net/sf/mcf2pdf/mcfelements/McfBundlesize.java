package net.sf.mcf2pdf.mcfelements;

public interface McfBundlesize {
	
	public McfPage getPage();
	
	public int getHeight();
	
	public int getWidth();
	
}
