/*******************************************************************************
 * ${licenseText}     
 *******************************************************************************/
package net.sf.mcf2pdf.mcfelements;

/**
 * TODO comment
 */
public interface McfClipart extends McfAreaContent {
	
	public String getUniqueName();
	public String getDesignElementId();


}
