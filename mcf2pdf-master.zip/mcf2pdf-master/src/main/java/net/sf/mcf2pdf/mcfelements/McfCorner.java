package net.sf.mcf2pdf.mcfelements;

public interface McfCorner {

	public int getLength();
	public String getShape();
	public String getWhere();
}
