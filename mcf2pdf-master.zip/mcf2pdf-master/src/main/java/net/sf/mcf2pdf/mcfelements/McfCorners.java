package net.sf.mcf2pdf.mcfelements;

import java.util.List;

public interface McfCorners {
	public List<? extends McfCorner> getCorners();
}
