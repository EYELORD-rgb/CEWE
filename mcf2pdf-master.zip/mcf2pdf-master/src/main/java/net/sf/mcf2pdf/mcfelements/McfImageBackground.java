/*******************************************************************************
 * ${licenseText}     
 *******************************************************************************/
package net.sf.mcf2pdf.mcfelements;

/**
 * TODO comment
 */
public interface McfImageBackground extends McfImage {
	
	public final static String RIGHT_OR_BOTTOM = "RIGHT_OR_BOTTOM";

	public String getBackgroundPosition();

}